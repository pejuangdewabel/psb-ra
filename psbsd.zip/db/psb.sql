/*
SQLyog Enterprise v12.4.3 (64 bit)
MySQL - 5.7.24 : Database - db_psbsd
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_psbsd` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_psbsd`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Admin',
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `admin` */

insert  into `admin`(`id`,`username`,`nama`,`email_verified_at`,`password`,`remember_token`,`created_at`,`updated_at`,`level`) values 
(1,'adminpsb','Prasetyo Bella',NULL,'$2y$10$7o2bSCvp3TncLcW0arH4RuCJ/MRkNvcJNShsJb/233hpG7pk8.LAO',NULL,'2021-07-25 19:23:05','2021-07-27 19:18:44','Admin');

/*Table structure for table `calon_siswa` */

DROP TABLE IF EXISTS `calon_siswa`;

CREATE TABLE `calon_siswa` (
  `no_pendaftaran` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `tgl_lahir_siswa` date DEFAULT NULL,
  `tmpt_lahir_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jk_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agama_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_anak_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anak_ke` int(11) DEFAULT NULL,
  `jml_saudara` int(11) DEFAULT NULL,
  `bahasa_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat_siswa` text COLLATE utf8mb4_unicode_ci,
  `kabupaten_kota_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provinsi_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kode_pos_siswa` int(11) DEFAULT NULL,
  `no_hp_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asal_sekolah_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tahun_kelulusan_siswa` year(4) DEFAULT NULL,
  `alamat_asal_sekolah` text COLLATE utf8mb4_unicode_ci,
  `nama_ayah_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl_lahir_ayah` date DEFAULT NULL,
  `pekerjaan_ayah_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nohp_ayah_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `penghasilan_ayah_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendidikan_ayah_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_ibu_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl_lahir_ibu` date DEFAULT NULL,
  `pekerjaan_ibu_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nohp_ibu_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `penghasilan_ibu_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendidikan_ibu_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat_ortu` text COLLATE utf8mb4_unicode_ci,
  `nama_wali_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl_lahir_wali` date DEFAULT NULL,
  `pekerjaan_wali_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nohp_wali_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `penghasilan_wali_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendidikan_wali_siswa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat_wali` text COLLATE utf8mb4_unicode_ci,
  `akte` longtext COLLATE utf8mb4_unicode_ci,
  `ijazah` longtext COLLATE utf8mb4_unicode_ci,
  `kk` longtext COLLATE utf8mb4_unicode_ci,
  `foto` longtext COLLATE utf8mb4_unicode_ci,
  `status_kelulusan` int(11) DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`no_pendaftaran`),
  KEY `calon_siswa_user_id_foreign` (`user_id`),
  CONSTRAINT `calon_siswa_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `calon_siswa` */

insert  into `calon_siswa`(`no_pendaftaran`,`user_id`,`tgl_lahir_siswa`,`tmpt_lahir_siswa`,`jk_siswa`,`agama_siswa`,`status_anak_siswa`,`anak_ke`,`jml_saudara`,`bahasa_siswa`,`alamat_siswa`,`kabupaten_kota_siswa`,`provinsi_siswa`,`kode_pos_siswa`,`no_hp_siswa`,`asal_sekolah_siswa`,`tahun_kelulusan_siswa`,`alamat_asal_sekolah`,`nama_ayah_siswa`,`tgl_lahir_ayah`,`pekerjaan_ayah_siswa`,`nohp_ayah_siswa`,`penghasilan_ayah_siswa`,`pendidikan_ayah_siswa`,`nama_ibu_siswa`,`tgl_lahir_ibu`,`pekerjaan_ibu_siswa`,`nohp_ibu_siswa`,`penghasilan_ibu_siswa`,`pendidikan_ibu_siswa`,`alamat_ortu`,`nama_wali_siswa`,`tgl_lahir_wali`,`pekerjaan_wali_siswa`,`nohp_wali_siswa`,`penghasilan_wali_siswa`,`pendidikan_wali_siswa`,`alamat_wali`,`akte`,`ijazah`,`kk`,`foto`,`status_kelulusan`,`deleted_at`,`created_at`,`updated_at`) values 
('PBD09019201',2,'2021-07-28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'2021-07-27 02:07:31','2021-07-27 10:36:36'),
('PBS2021170009804',3,'2009-03-14','Bandar Lampung','P','Islam','Kandung',3,3,'Indonesia','Jl. R. Gunawan II','Bandar Lampung','Lampung',35144,'088287124803','SD Negeri 2',2020,'Jl. Zainal Abidin Pagar Alam, Bandar Lampung, Lampung','Yardi','1966-04-04','PNS','085840957000','3000000','Sekolah Menengah Atas / SMU','Magdalena','1968-08-15','Ibu Rumah Tangga','081541212011','0','Sarjana 1','Jl. Zainal Abidin Pagar Alam, Bandar Lampung, Lampung',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/PBS2021170009804/Kxxcws48XTnwKN5aUiWAQO4Mx3a42B1mclDE0jGp.jpg','assets/PBS2021170009804/v5WWCQLmtVT8H076FnojkKPlJLGX05iYRnxPdH4p.jpg','assets/PBS2021170009804/yBWC0ywkWAJ05t2QdZtDTsdsJ8V3N5q8H5oi8SVv.jpg','assets/PBS2021170009804/McoQIJV0sw6AhlHdAxSvEwkeF9VF9SDCMm5HRMBa.jpg',2,NULL,'2021-07-29 02:42:52','2021-07-29 11:29:53'),
('PBS2021280002569',1,'2021-07-15','a','L','Islam','Kandung',1,3,'Indo','aaaaaaaaaa','aaaaaaaaaaa','aaaaaaaaaaaa',35144,'0891281021','aaaa',2020,'aaaaaaaaaaaaa','aaaaaaaaaaa','2021-07-30','aaaaaaaaaa','089102181911','1000000','Sarjana 1','aaaaaaaaaaaaaa','2021-07-29','aaaaaaaaaaaa','0891901291','1000000','Sarjana 1','aaaaaaaaaaaaaaaaaaaaaa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/PBS2021280002569/UFrTSIeWn2D3p9RWkT6ZcMiIuUX6a2BCbx4tXJjV.jpg','assets/PBS2021280002569/QOuNR2hcqAEuAzYMAiiN1ttoUqGDNYmuitPPQmTi.jpg','assets/PBS2021280002569/as88f1PsY5MSR06dfO0EB0mIGPAiNbvZPBMk3weP.jpg','assets/PBS2021280002569/MBh1NIjbwXrvoFrTLnz5ELEeorvuxOQF7kQ5WGFL.jpg',1,NULL,'2021-07-28 20:00:12','2021-07-29 01:44:55');

/*Table structure for table `failed_jobs` */

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `failed_jobs` */

/*Table structure for table `informasi` */

DROP TABLE IF EXISTS `informasi`;

CREATE TABLE `informasi` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_thn_ajaran` bigint(20) unsigned NOT NULL,
  `pendaftaran_awal` date NOT NULL,
  `pendaftaran_akhir` date NOT NULL,
  `pengumuman` date NOT NULL,
  `daftar_ulang_awal` date NOT NULL,
  `daftar_ulang_akhir` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `informasi_id_thn_ajaran_foreign` (`id_thn_ajaran`),
  CONSTRAINT `informasi_id_thn_ajaran_foreign` FOREIGN KEY (`id_thn_ajaran`) REFERENCES `tahun_ajaran` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `informasi` */

insert  into `informasi`(`id`,`id_thn_ajaran`,`pendaftaran_awal`,`pendaftaran_akhir`,`pengumuman`,`daftar_ulang_awal`,`daftar_ulang_akhir`,`created_at`,`updated_at`) values 
(2,3,'2021-08-01','2021-08-07','2021-08-08','2021-08-09','2021-08-10','2021-07-26 14:02:25','2021-07-26 14:08:07');

/*Table structure for table `kelas` */

DROP TABLE IF EXISTS `kelas`;

CREATE TABLE `kelas` (
  `kode_kelas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kapasitas_kelas` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`kode_kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `kelas` */

insert  into `kelas`(`kode_kelas`,`kapasitas_kelas`,`created_at`,`updated_at`) values 
('1A',20,'2021-07-26 11:16:02','2021-07-27 20:06:27'),
('1B',10,'2021-07-26 12:09:35','2021-07-26 12:09:35'),
('1C',20,'2021-07-27 20:06:19','2021-07-27 20:06:33');

/*Table structure for table `kelulusan_siswa` */

DROP TABLE IF EXISTS `kelulusan_siswa`;

CREATE TABLE `kelulusan_siswa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tahunajaran` bigint(20) unsigned NOT NULL,
  `nopendaftaran` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_kelas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kelulusan_siswa_tahunajaran_foreign` (`tahunajaran`),
  KEY `kelulusan_siswa_nama_kelas_foreign` (`nama_kelas`),
  KEY `kelulusan_siswa_nopendaftaran_foreign` (`nopendaftaran`),
  CONSTRAINT `kelulusan_siswa_nama_kelas_foreign` FOREIGN KEY (`nama_kelas`) REFERENCES `kelas` (`kode_kelas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kelulusan_siswa_nopendaftaran_foreign` FOREIGN KEY (`nopendaftaran`) REFERENCES `calon_siswa` (`no_pendaftaran`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kelulusan_siswa_tahunajaran_foreign` FOREIGN KEY (`tahunajaran`) REFERENCES `tahun_ajaran` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `kelulusan_siswa` */

insert  into `kelulusan_siswa`(`id`,`tahunajaran`,`nopendaftaran`,`nama_kelas`,`deleted_at`,`created_at`,`updated_at`) values 
(8,2,'PBD09019201','1A',NULL,'2021-07-27 10:36:35','2021-07-27 11:12:19'),
(9,3,'PBS2021280002569','1A',NULL,'2021-07-29 01:44:55','2021-07-29 01:44:55');

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

insert  into `migrations`(`id`,`migration`,`batch`) values 
(1,'2014_10_12_000000_create_users_table',1),
(2,'2014_10_12_100000_create_password_resets_table',1),
(3,'2019_08_19_000000_create_failed_jobs_table',1),
(4,'2021_07_25_165037_create_admin_table',1),
(5,'2021_07_25_190005_add_level_to_users_table',2),
(6,'2021_07_25_191318_add_level_to_admin_table',3),
(9,'2021_07_25_203759_create_kelas_table',4),
(10,'2021_07_25_204044_create_informasi_table',4),
(11,'2021_07_25_204152_create_tahun_ajaran_table',4),
(13,'2021_07_25_214749_create_calon_siswa_table',5),
(16,'2021_07_25_221656_create_kelulusan_siswa_table',6),
(17,'2021_07_25_224653_create_kelulusan_siswa_table',7),
(18,'2021_07_25_224909_add_tambah_foreign_kelulusan_siswa_table',8),
(19,'2021_07_26_142653_add_foreign_key_to_calon_siswa_table',9);

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `password_resets` */

/*Table structure for table `tahun_ajaran` */

DROP TABLE IF EXISTS `tahun_ajaran`;

CREATE TABLE `tahun_ajaran` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date1` year(4) NOT NULL,
  `date2` year(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tahun_ajaran` */

insert  into `tahun_ajaran`(`id`,`date1`,`date2`,`created_at`,`updated_at`) values 
(2,2020,2021,'2021-07-26 12:40:50','2021-07-26 12:40:50'),
(3,2021,2022,'2021-07-26 12:52:42','2021-07-26 12:52:42');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nik` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Siswa',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_nik_unique` (`nik`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`nik`,`nama`,`email_verified_at`,`password`,`remember_token`,`created_at`,`updated_at`,`level`) values 
(1,'1807290121280002','Ahmad',NULL,'$2y$10$EXp0stnCZPKAqkHvr3kcSO434QY6g6tFKrgYqfiVlDIPiB1E6Nqpm',NULL,'2021-07-25 17:33:20','2021-07-29 01:43:24','Siswa'),
(2,'1831019101291012','Rani',NULL,'$2y$10$i7QuxBd7kOFClH36owcbH.Xx.iBs/9Hp8uX9HApqPhWD4QEcDvMZm',NULL,'2021-07-27 11:25:44','2021-07-27 11:25:45','Siswa'),
(3,'1890128190170009','Fani Maulinda Sindi',NULL,'$2y$10$ELzHfDnzYvpdJGyxW6AFUeMS1J4a83NG/GscZvC6hb6cM4bIWVCxq',NULL,'2021-07-29 02:19:04','2021-07-29 02:19:04','Siswa');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
