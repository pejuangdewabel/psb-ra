

<?php $__env->startSection('content'); ?>        
        <section class="content">
          <!-- Default box -->
          <pendaftar-component></pendaftar-component>
          <!-- /.card -->
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',[
  'tahunAjaran' => $tahun
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel\psbsd\resources\views/pages/admin/pendaftar.blade.php ENDPATH**/ ?>