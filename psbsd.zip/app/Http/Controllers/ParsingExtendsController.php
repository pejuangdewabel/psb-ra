<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ParsingExtendsController extends Controller
{
    protected $layout = 'layouts.user';
}
